function [x_min, f_min, iter] = Newton_wolfe(f, gf, Hf, x0, Stop_tol, c1, c2, varargin)
    tol = inf;
    x_iter = x0;
    iter = 0;
    %intervals for GSS : 
    %a = 0;
    %b = 100;
    f_iter = f(x0);
    delta_f = f_iter;
    alpha_max = 100;  %to be somehow similar to prev homework
    %or can use the formula including fbar

    while (tol>Stop_tol)
        H_iter = Hf(x_iter); %assuming H is psd
        g_iter = gf(x_iter);
        p_iter = - H_iter\g_iter;

        phi = @(alpha) f(x_iter + alpha*p_iter, varargin{:});
        phi_prime = @(alpha) p_iter'* gf(x_iter + alpha*p_iter, varargin{:});
        [alpha_iter, flag, f_new] = bracketing(phi, phi_prime, c1, c2, alpha_max, delta_f);
        if flag == 1  %not sure that its correct for newton (though it works!)
            f_iter = f_new;
            break
        end
        x_new = x_iter + alpha_iter.*p_iter;
        %f_new = f(x_new);
        delta_f = f_iter - f_new;  %not the reverse?
        tol = norm(x_new - x_iter);
        iter = iter + 1;
        x_iter = x_new;
        f_iter = f_new;
    end
    x_min = x_iter;
    f_min = f_iter;
end