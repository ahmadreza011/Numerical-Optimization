function [x_min, f_min, iter] = BFGS(f, gf, x0, Stop_tol, c1, c2, varargin)
    tol = inf;
    x_iter = x0;
    iter = 0;
    f_iter = f(x0);
    delta_f = f_iter;
    alpha_max = 100;  %to be somehow similar to prev homeworks
    %or can use the formula including fbar
    g_iter = gf(x0);
    I = eye(length(x0));
    C_iter = I;
 
    while (tol>Stop_tol)         
        p_iter = - C_iter * g_iter;  
        phi = @(alpha) f(x_iter + alpha*p_iter, varargin{:});
        phi_prime = @(alpha) p_iter'* gf(x_iter + alpha*p_iter, varargin{:});
        [alpha_iter, flag, f_new] = bracketing(phi, phi_prime, c1, c2, alpha_max, delta_f);
        if flag == 1  %not sure that if its correct for BFGS
            f_iter = f_new;
            break
        end
        x_new = x_iter + alpha_iter.*p_iter;
        g_new = gf(x_new);
        delta_f = f_iter - f_new;  %not the reverse?
        delta_iter = x_new - x_iter;
        gamma_iter = g_new - g_iter;
        if iter == 0
            C_iter = ((gamma_iter'*delta_iter)/(gamma_iter'*gamma_iter)) * I;
        end     %not else!
        a = 1/(delta_iter'*gamma_iter);
        C_iter = (I- a*delta_iter*gamma_iter') * C_iter * (I- a*gamma_iter*delta_iter') + a*(delta_iter*delta_iter');
        tol = norm(g_new);
        x_iter = x_new;
        f_iter = f_new;
        g_iter = g_new ;
        iter = iter + 1;
    end
    x_min = x_iter;
    f_min = f_iter;
end
