function [alpha, flag, phi_alpha] = sectioning(phi, phi_prime, c1, c2, a, b, varargin)
    phi0 = phi(0);
    phi_prime0 = phi_prime(0);
    flag = 0;
    phi_prime_a = phi_prime(a);
    %phi_prime00 = (b-a)*phi_prime_a;
    phi_a = phi(a);
    phi_b = phi(b);
    while(true)
        %phi_alpha = phi(alpha);
%         phi_prime_a = phi_prime(a);
        if abs((a-b)*phi_prime_a) <= eps
            alpha = (a+b)/2;    %or the other choice
            %note that in this case there is no need to define flag
            phi_alpha = phi(alpha);
            flag = 1;
            break
        end
        phi_prime00 = (b-a)*phi_prime_a;
        %phi_prime0 = phi_prime_a;
%         phi_a = phi(a);
        z = -phi_prime00/(2*(phi_b-phi_a-phi_prime00));
        %if z==0 || z==1
        %    flag = 1;
        %end
        alpha = a + z.*(b-a);
        phi_alpha = phi(alpha);
        if (phi_alpha > phi0 + c1 * alpha * phi_prime0) || (phi_alpha>=phi_a)
            cand_a = a;
            cand_b = alpha;
            phi_cand_a = phi_a;
            phi_prime_cand_a = phi_prime_a;
            phi_cand_b = phi_alpha;
        else
            phi_prime_alpha = phi_prime(alpha);
            if abs(phi_prime_alpha) <= - c2 * phi_prime0
                break
            end
            cand_a = alpha;
            %phi_prev = phi_a;
            phi_cand_a = phi_alpha;
            phi_prime_cand_a = phi_prime_alpha;
            if (b-a) * phi_prime_alpha > 0
                cand_b = a;
                phi_cand_b = phi_a;
            else
                cand_b = b;
                phi_cand_b = phi_b;
            end
        end
        if abs(cand_a - cand_b) < 0.5 * abs(a-b)
            a = cand_a;
            b = cand_b;
            phi_a = phi_cand_a;
            phi_b = phi_cand_b;
            phi_prime_a = phi_prime_cand_a;
            %flag = 2;
            continue
        end
        %if flag==0
        alpha = (a + b)/2;
        phi_alpha = phi(alpha);
        if (phi_alpha > phi0 + c1 * alpha * phi_prime0) || (phi_alpha>=phi_a)
            b = alpha;
            phi_b = phi_alpha;
        else
            phi_prime_alpha = phi_prime(alpha);
            if abs(phi_prime_alpha) <= - c2 * phi_prime0
                break
            end
            a_prev = a;
            phi_prev_a = phi_a;
            a = alpha;
            phi_a = phi_alpha;
            phi_prime_a = phi_prime_alpha;
            if (b-a_prev) * phi_prime_alpha > 0   %no need to use b_prev.. (if .. else..)
                b = a_prev;    %not a!
                phi_b = phi_prev_a;
            end
        end
    end
end

