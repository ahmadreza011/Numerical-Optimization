function [alpha, flag, phi_final] = bracketing(phi, phi_prime, c1, c2, alpha_max, delta_f)  %do we need flag output? 
    phi0 = phi(0);
    phi_prime0 = phi_prime(0);
    alpha0 = 0;
    phi_alpha0 = phi0;
    alpha1 = min(1,abs(-2.02*delta_f/phi_prime0));
    while(true)     
        phi_alpha1 = phi(alpha1);   %using zero as i-1 and 1 as i in next iterations..
        if (phi_alpha1 > phi0 + c1 * alpha1 * phi_prime0) || (phi_alpha1>=phi_alpha0)   %need i>1?
            [alpha, flag, phi_final] = sectioning(phi, phi_prime, c1, c2, alpha0, alpha1);
            break
        end
        phi_prime_alpha_1 = phi_prime(alpha1);
        if abs(phi_prime_alpha_1) <= - c2 * phi_prime0
            alpha = alpha1;
            phi_final = phi_alpha1;  %better!
            flag = 0;
            break
        end
        if phi_prime_alpha_1 >= 0
            [alpha, flag, phi_final] = sectioning(phi, phi_prime, c1, c2, alpha1, alpha0);
            break
        end
        alpha0_old = alpha0;
        alpha0 = alpha1;
        %phi_alpha0 = phi(alpha0);
        phi_alpha0 = phi_alpha1;
        if alpha_max <= 2*alpha1 - alpha0_old
            alpha1 = alpha_max;
        else
            T1 = 10;
            %instead of next line, can also use the choosing method in
            %sectioning (interpolation using 2nd order polynomials)
            alpha1 = mean([2*alpha1 - alpha0_old, min(alpha_max, alpha1 + T1*(alpha1 - alpha0_old))]);
        end
    end
end