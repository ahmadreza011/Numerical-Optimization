function [x_min, f_min, iter] = Newton_GSS(f, gf, Hf, x0, Stop_tol, GSS_tol, varargin)
    tol = inf;
    x_iter = x0;
    iter = 0;
    %intervals for GSS : 
    a = 0;
    b = 100;

    while (tol>Stop_tol)
        H_iter = Hf(x_iter); %assuming H is psd
        g_iter = gf(x_iter);
        p_iter = - H_iter\g_iter;

        %[alpha_iter, ~] = GSS(@(alpha) f(x_iter + alpha*p_iter, varargin{:}), a, b, GSS_tol, varargin{:});
        [alpha_iter, ~] = GSS_2(@(alpha) f(x_iter + alpha*p_iter, varargin{:}), a, b, GSS_tol, varargin{:});
        x_new = x_iter + alpha_iter.*p_iter;
        tol = norm(x_new - x_iter);
        iter = iter + 1;
        x_iter = x_new;
    end
    x_min = x_iter;
    f_min = f(x_min, varargin{:});
end