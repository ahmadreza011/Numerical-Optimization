function [x_min, N] = GSS_2(f, a, b, epsilon, varargin)    
    if (b - a < epsilon)
        x_min = (a + b) / 2;
        N = 0;
        return
    end
    rho = (3 - sqrt(5)) / 2;
    a_i = a + rho * (b - a);
    b_i = a + (1 - rho) * (b - a);
    % only two calls we make before the loop.
    f_a = f(a_i, varargin{:});
    f_b = f(b_i, varargin{:});
    N = 1;
    while true
        if (f_a < f_b)
            b = b_i;
            b_i = a_i;
            f_b = f_a; %reusing the value
            a_i = a + rho * (b - a);
            f_a = f(a_i, varargin{:});  
        else
            a = a_i;
            a_i = b_i;
            f_a = f_b;
            b_i = a + (1 - rho) * (b - a);
            f_b = f(b_i, varargin{:});
        end
        if (b - a < epsilon)
            break
        end
        N = N + 1;
    end
    x_min = (a + b) / 2;
end

