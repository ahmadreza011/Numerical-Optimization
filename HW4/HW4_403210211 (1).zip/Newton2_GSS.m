function [x_min, f_min, iter] = Newton2_GSS(f, gf, Hf, x0, Stop_tol, GSS_tol, varargin)
    tol = inf;
    x_iter = x0;
    iter = 0;
    %intervals for GSS :
    a = 0;
    b = 100;
    n = length(x0);

    while (tol > Stop_tol)
        g_iter = gf(x_iter);
        H_iter = Hf(x_iter); 
        
        % Cholesky with Added Multiple of Identity
        % We want to solve (H + mu*I)p = -g
        mu = 0;
        while true
            [R, flag] = chol(H_iter + mu * eye(n)); % decomposing H + mu*I
            if flag == 0 % matrix is PD.
                break; 
            end
            % matrix is not PSD
            if mu == 0
                mu = 1e-3;
            else
                mu = mu * 10;
            end
        end 
        % Solve for search direction using Cholesky factors
        % (H + mu*I) = R'*R  ==> R'*(R*p) = -g
        p_iter = - (R \ (R' \ g_iter));
        [alpha_iter, ~] = GSS(@(alpha) f(x_iter + alpha*p_iter, varargin{:}), a, b, GSS_tol);
        x_new = x_iter + alpha_iter * p_iter;
        tol = norm(x_new - x_iter);
        iter = iter + 1;
        x_iter = x_new;
    end
    x_min = x_iter;
    f_min = f(x_min, varargin{:});
end